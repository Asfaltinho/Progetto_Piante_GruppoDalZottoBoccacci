export default function InfoBox() {
  return (
    <div className="info-box">
      <ul>
        <li>CARATTERISTICHE GENERALI DELLA PIANTA</li>
      </ul>
    </div>
  );
}
